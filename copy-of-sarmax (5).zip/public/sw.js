
self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open('sarmax-v1').then(c => c.addAll(['/', '/index.html']))
  );
});

self.addEventListener('fetch', (e) => {
  // Cache images/posters
  if (e.request.destination === 'image') {
    e.respondWith(
      caches.match(e.request).then(r => 
        r || fetch(e.request).then(resp => {
          return caches.open('sarmax-images').then(c => {
            c.put(e.request, resp.clone());
            return resp;
          });
        }).catch(() => caches.match('/default_poster.jpg'))
      )
    );
  }
});
