import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, Bell, ChevronDown, Menu, X, User } from 'lucide-react';
import Logo from './Logo';
import { useAuth } from '../context/AuthContext';

const Navbar: React.FC<{ isScrolled: boolean }> = ({ isScrolled }) => {
    const { user, logOut } = useAuth();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const location = useLocation();

    // Close mobile menu when route changes
    useEffect(() => {
        setIsMobileMenuOpen(false);
    }, [location]);

    const navLinks = [
        { name: 'Home', path: '/' },
        { name: 'TV Shows', path: '/tv' },
        { name: 'Movies', path: '/movies' },
        { name: 'New & Popular', path: '/new' },
        { name: 'My List', path: '/list' },
    ];

    // Background logic: Solid if scrolled OR menu is open, otherwise gradient
    const navBackground = (isScrolled || isMobileMenuOpen) 
        ? 'bg-[#0D0D0F] shadow-lg border-b border-[#5D5FFF]/10' 
        : 'bg-gradient-to-b from-black/90 to-transparent';

    return (
        <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${navBackground}`}>
            <div className="flex items-center justify-between px-4 md:px-12 h-[68px]">
                <div className="flex items-center gap-4 md:gap-8">
                    {/* Mobile Menu Toggle - Visible on mobile */}
                    <button 
                        className="md:hidden text-white p-1 hover:bg-white/10 rounded-full transition-colors" 
                        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                    >
                        {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                    </button>

                    <Link to="/" className="flex-shrink-0"><Logo className="h-6 md:h-8" /></Link>
                    
                    {/* Desktop Navigation - Hidden on mobile */}
                    <ul className="hidden md:flex gap-6 text-sm text-gray-300 font-medium">
                        {navLinks.map(link => (
                            <li key={link.path}>
                                <Link 
                                    to={link.path} 
                                    className={`hover:text-[#5D5FFF] transition-colors ${location.pathname === link.path ? 'text-white font-bold' : ''}`}
                                >
                                    {link.name}
                                </Link>
                            </li>
                        ))}
                    </ul>
                </div>

                {/* Right Side Icons */}
                <div className="flex items-center gap-4 md:gap-6 text-white">
                    <Link to="/search"><Search className="w-5 h-5 cursor-pointer hover:text-[#5D5FFF] transition-colors" /></Link>
                    <Bell className="w-5 h-5 cursor-pointer hover:text-[#5D5FFF] transition-colors hidden sm:block" />
                    
                    <div className="group relative flex items-center gap-1 cursor-pointer">
                        <div className="w-8 h-8 rounded bg-[#5D5FFF] flex items-center justify-center text-sm font-bold overflow-hidden border border-white/20">
                            {user?.email?.[0].toUpperCase() || <User className="w-5 h-5" />}
                        </div>
                        <ChevronDown className="w-4 h-4 group-hover:rotate-180 transition-transform hidden sm:block" />
                        
                        {/* Dropdown Menu */}
                        <div className="absolute right-0 top-full pt-2 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-opacity">
                            <div className="bg-[#1A1A1D] border border-[#5D5FFF]/20 w-48 py-2 rounded-xl shadow-xl">
                                <div className="px-4 py-2 border-b border-white/5 mb-2">
                                    <p className="text-xs text-gray-400">Signed in as</p>
                                    <p className="text-sm font-bold truncate">{user?.email || 'Guest'}</p>
                                </div>
                                <Link to="/profile" className="block px-4 py-2 text-sm hover:bg-[#5D5FFF]/10 hover:text-[#5D5FFF]">Manage Profiles</Link>
                                <Link to="/settings" className="block px-4 py-2 text-sm hover:bg-[#5D5FFF]/10 hover:text-[#5D5FFF]">Account Settings</Link>
                                <Link to="/list" className="block px-4 py-2 text-sm hover:bg-[#5D5FFF]/10 hover:text-[#5D5FFF]">Watchlist</Link>
                                <div className="border-t border-white/5 my-2"></div>
                                <button onClick={logOut} className="block w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-red-500/10">Sign out</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Mobile Menu Drawer - Responsive Full Width */}
            <div className={`md:hidden absolute top-[68px] left-0 w-full bg-[#0D0D0F] border-b border-[#5D5FFF]/20 shadow-2xl overflow-hidden transition-all duration-300 ease-in-out ${isMobileMenuOpen ? 'max-h-[400px] opacity-100' : 'max-h-0 opacity-0'}`}>
                <ul className="flex flex-col p-4 gap-2">
                    {navLinks.map(link => (
                        <li key={link.path}>
                            <Link 
                                to={link.path} 
                                onClick={() => setIsMobileMenuOpen(false)}
                                className={`block p-3 rounded-lg text-base font-medium transition-colors ${location.pathname === link.path ? 'bg-[#5D5FFF]/10 text-[#5D5FFF]' : 'text-gray-300 hover:bg-white/5'}`}
                            >
                                {link.name}
                            </Link>
                        </li>
                    ))}
                    <li className="mt-2 border-t border-white/10 pt-2">
                        <button onClick={() => { logOut(); setIsMobileMenuOpen(false); }} className="block w-full text-left p-3 text-red-400 hover:bg-red-500/10 rounded-lg font-medium">
                            Sign Out
                        </button>
                    </li>
                </ul>
            </div>
        </nav>
    );
};

export default Navbar;