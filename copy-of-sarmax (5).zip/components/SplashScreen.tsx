
import React, { useEffect, useState } from 'react';
import Logo from './Logo';

const SplashScreen: React.FC<{ onFinish: () => void }> = ({ onFinish }) => {
    const [visible, setVisible] = useState(true);
    const [step, setStep] = useState(0);

    useEffect(() => {
        // Cinematic Timeline
        setTimeout(() => setStep(1), 200); // Fade In Bg
        setTimeout(() => setStep(2), 800); // Logo Burst
        setTimeout(() => setStep(3), 1800); // Text Slide
        setTimeout(() => setStep(4), 3500); // Fade Out
        
        const timer = setTimeout(() => {
            setVisible(false);
            onFinish();
        }, 4000);

        return () => clearTimeout(timer);
    }, [onFinish]);

    if (!visible) return null;

    return (
        <div className={`fixed inset-0 z-[100] bg-black flex items-center justify-center transition-opacity duration-700 ${step === 4 ? 'opacity-0' : 'opacity-100'}`}>
            {/* Animated Background Grid */}
            <div className="absolute inset-0 bg-[url('https://assets.nflxext.com/ffe/siteui/vlv3/f841d4c7-10e1-40af-bcae-07a3f8dc141a/f6d7434e-d6de-4185-a6d4-c77a2d08737b/US-en-20220502-popsignuptwoweeks-perspective_alpha_website_large.jpg')] bg-cover opacity-10 blur-xl scale-110 animate-pulse"></div>
            
            <div className="relative flex flex-col items-center z-10">
                {/* Logo Animation */}
                <div className={`transition-all duration-1000 cubic-bezier(0.34, 1.56, 0.64, 1) transform ${step >= 2 ? 'scale-150 opacity-100 translate-y-0' : 'scale-50 opacity-0 translate-y-10'}`}>
                    <Logo className="h-24 md:h-32 w-auto drop-shadow-[0_0_50px_rgba(93,95,255,0.8)]" />
                </div>
                
                {/* Tagline Animation */}
                <div className={`mt-12 text-center overflow-hidden`}>
                    <p className={`text-white font-black text-lg md:text-2xl tracking-[0.5em] uppercase transition-all duration-1000 transform ${step >= 3 ? 'translate-y-0 opacity-100' : 'translate-y-full opacity-0'}`}>
                        The Future of Streaming
                    </p>
                    <div className={`h-1 w-32 mx-auto mt-4 bg-[#5D5FFF] rounded-full transition-all duration-1000 delay-500 ${step >= 3 ? 'w-32 opacity-100' : 'w-0 opacity-0'}`}></div>
                </div>
            </div>
        </div>
    );
};

export default SplashScreen;
