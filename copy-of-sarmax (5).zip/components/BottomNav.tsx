
import React from 'react';
import { Home, Film, Search, Settings, Trophy } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const BottomNav: React.FC = () => {
  const location = useLocation();

  const tabs = [
    { name: 'Home', icon: Home, path: '/' },
    { name: 'Search', icon: Search, path: '/search' },
    { name: 'Sports', icon: Trophy, path: '/football' },
    { name: 'Settings', icon: Settings, path: '/settings' },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 w-full bg-[#0D0D0F]/90 backdrop-blur-lg border-t border-[#5D5FFF]/10 z-40 pb-safe">
      <div className="flex items-center justify-around p-3">
        {tabs.map((tab) => {
          const isActive = location.pathname === tab.path;
          return (
            <Link 
              key={tab.name} 
              to={tab.path}
              className={`flex flex-col items-center gap-1 transition-all ${isActive ? 'text-[#5D5FFF] scale-110' : 'text-gray-500 hover:text-gray-300'}`}
            >
              <tab.icon className={`w-6 h-6 ${isActive ? 'drop-shadow-[0_0_8px_rgba(93,95,255,0.6)]' : ''}`} />
              <span className="text-[10px] font-medium">{tab.name}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
};

export default BottomNav;
