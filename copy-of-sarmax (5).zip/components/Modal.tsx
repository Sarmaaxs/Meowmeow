import React, { useState, useEffect } from 'react';
import { X, Play, ArrowLeft, Download, MessageSquare, Globe } from 'lucide-react';
import { Movie } from '../types';
import { resolveBackdrop } from '../utils';
import SmartImage from './SmartImage';
import { MOCK_DATA, getPosterUrl } from '../constants';

const Modal: React.FC<{ movie: Movie; onClose: () => void }> = ({ movie, onClose }) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [season, setSeason] = useState(1);
    const [episode, setEpisode] = useState(1);
    const [server, setServer] = useState(1);
    const [downloading, setDownloading] = useState(false);
    const [similarMovies, setSimilarMovies] = useState<Movie[]>([]);

    const isTv = movie.media_type === 'tv' || (movie.title && movie.title.includes('Season'));

    useEffect(() => {
        const all = MOCK_DATA.categories.flatMap(c => c.items);
        const similar = all
            .filter(m => m.id !== movie.id && m.media_type === movie.media_type)
            .sort(() => 0.5 - Math.random())
            .slice(0, 6);
        setSimilarMovies(similar);
    }, [movie]);

    const getStreamUrl = () => {
        switch (server) {
            case 1: return isTv ? `https://vidsrc.pro/embed/tv/${movie.id}/${season}/${episode}` : `https://vidsrc.pro/embed/movie/${movie.id}`;
            case 2: return isTv ? `https://vidlink.pro/tv/${movie.id}/${season}/${episode}` : `https://vidlink.pro/movie/${movie.id}`;
            case 3: return isTv ? `https://embed.su/embed/tv/${movie.id}/${season}/${episode}` : `https://embed.su/embed/movie/${movie.id}`;
            case 4: return isTv ? `https://vidsrc.cc/v2/embed/tv/${movie.id}/${season}/${episode}` : `https://vidsrc.cc/v2/embed/movie/${movie.id}`;
            case 5: return isTv ? `https://multiembed.mov/?video_id=${movie.id}&tmdb=1&s=${season}&e=${episode}` : `https://multiembed.mov/?video_id=${movie.id}&tmdb=1`;
            case 6: return isTv ? `https://www.2embed.cc/embedtv/${movie.id}&s=${season}&e=${episode}` : `https://www.2embed.cc/embed/${movie.id}`;
            default: return `https://vidsrc.pro/embed/movie/${movie.id}`;
        }
    };

    const getServerName = (s: number) => {
        switch(s) {
            case 1: return 'VidSrc.pro (Best)';
            case 2: return 'VidLink (Fast)';
            case 3: return 'Embed.su (Clean)';
            case 4: return 'VidSrc.cc';
            case 5: return 'SuperEmbed';
            case 6: return '2Embed';
            default: return `Server ${s}`;
        }
    };

    const handleDownload = () => {
        setDownloading(true);
        setTimeout(() => {
            setDownloading(false);
            alert(`Added ${movie.title} to Downloads (Simulated)`);
        }, 1500);
    };

    return (
        <div className="fixed inset-0 z-[60] bg-black/90 backdrop-blur-md flex justify-center items-center p-0 md:p-4 animate-fade-in" onClick={onClose}>
            <div className="relative w-full max-w-6xl bg-[#151517] md:rounded-2xl shadow-2xl overflow-hidden h-full md:h-auto md:max-h-[95vh] flex flex-col border border-[#5D5FFF]/10" onClick={e => e.stopPropagation()}>
                
                <button 
                    onClick={() => isPlaying ? setIsPlaying(false) : onClose()} 
                    className="absolute top-4 right-4 z-50 bg-black/60 hover:bg-[#5D5FFF] text-white rounded-full p-2 transition-colors backdrop-blur-md group"
                >
                    {isPlaying ? <ArrowLeft className="w-6 h-6"/> : <X className="w-6 h-6 group-hover:rotate-90 transition-transform"/>}
                </button>

                {isPlaying ? (
                    <div className="w-full h-full bg-black flex flex-col">
                        <div className="relative flex-1 bg-black">
                            <iframe
                                src={getStreamUrl()}
                                title={movie.title}
                                className="w-full h-full absolute inset-0"
                                frameBorder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                                allowFullScreen
                                // Sandbox removed to allow streaming scripts to load
                            ></iframe>
                        </div>
                        <div className="bg-[#1A1A1D] p-4 border-t border-[#5D5FFF]/10 flex flex-wrap items-center justify-between gap-4">
                            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
                                <Globe className="w-4 h-4 text-[#5D5FFF]" />
                                {[1, 2, 3, 4, 5, 6].map(s => (
                                    <button 
                                        key={s}
                                        onClick={() => setServer(s)}
                                        className={`px-3 py-1.5 rounded-lg text-[10px] md:text-xs font-bold transition-all whitespace-nowrap ${server === s ? 'bg-[#5D5FFF] text-white shadow-[0_0_10px_rgba(93,95,255,0.3)]' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'}`}
                                    >
                                        {getServerName(s)}
                                    </button>
                                ))}
                            </div>
                            {isTv && (
                                <div className="flex items-center gap-2">
                                    <select value={season} onChange={(e) => setSeason(Number(e.target.value))} className="bg-[#0D0D0F] text-white text-xs p-2 rounded border border-gray-700 cursor-pointer hover:border-[#5D5FFF]"><option value="1">S1</option><option value="2">S2</option><option value="3">S3</option><option value="4">S4</option></select>
                                    <select value={episode} onChange={(e) => setEpisode(Number(e.target.value))} className="bg-[#0D0D0F] text-white text-xs p-2 rounded border border-gray-700 cursor-pointer hover:border-[#5D5FFF]">{[...Array(24)].map((_,i)=><option key={i} value={i+1}>Ep {i+1}</option>)}</select>
                                </div>
                            )}
                        </div>
                    </div>
                ) : (
                    <div className="flex-1 overflow-y-auto no-scrollbar bg-[#0D0D0F]">
                        <div className="relative h-[45vh] md:h-[500px]">
                            <div className="w-full h-full">
                                <img src={resolveBackdrop(movie)} className="w-full h-full object-cover opacity-60" alt={movie.title} />
                            </div>
                            <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0F] via-[#0D0D0F]/40 to-transparent" />
                            
                            <div className="absolute bottom-0 left-0 w-full p-6 md:p-10 max-w-3xl">
                                <h1 className="text-3xl md:text-5xl font-black text-white mb-4 drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)] leading-none">{movie.title}</h1>
                                
                                <div className="flex flex-wrap items-center gap-4 mb-6">
                                    <button onClick={() => setIsPlaying(true)} className="bg-white hover:bg-gray-200 text-black px-8 py-3.5 rounded-xl font-black text-lg flex items-center gap-2 transition-all shadow-[0_0_20px_rgba(255,255,255,0.3)] hover:scale-105 active:scale-95">
                                        <Play className="fill-black w-6 h-6"/> Play Free
                                    </button>
                                    <button onClick={() => window.open(`https://www.youtube.com/results?search_query=${movie.title}+trailer`)} className="bg-[#5D5FFF]/20 hover:bg-[#5D5FFF]/40 text-[#5D5FFF] border border-[#5D5FFF]/50 px-6 py-3.5 rounded-xl font-bold text-lg transition-all backdrop-blur-md">
                                        Trailer
                                    </button>
                                    <button onClick={handleDownload} className="p-3.5 bg-gray-800/60 text-white rounded-xl hover:bg-gray-700 transition-colors border border-white/10">
                                        {downloading ? <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"/> : <Download className="w-6 h-6" />}
                                    </button>
                                </div>

                                <div className="flex items-center gap-4 text-sm font-medium text-gray-300">
                                    <span className="text-[#46d369] font-bold text-base">{movie.match || 98}% Match</span>
                                    <span>{movie.year}</span>
                                    <span className="border border-gray-600 px-2 py-0.5 text-xs rounded bg-[#1A1A1D]">HD</span>
                                    <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3"/> {movie.vote_average || 8.5}</span>
                                </div>
                            </div>
                        </div>

                        <div className="p-6 md:p-10 grid grid-cols-1 lg:grid-cols-3 gap-10">
                            <div className="lg:col-span-2 space-y-8">
                                <div>
                                    <h3 className="text-lg font-bold text-white mb-2">Synopsis</h3>
                                    <p className="text-gray-300 text-lg leading-relaxed font-light">{movie.overview || "No description available."}</p>
                                </div>
                                
                                {movie.cast && (
                                    <div>
                                        <h3 className="text-lg font-bold text-white mb-4">Cast</h3>
                                        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
                                            {movie.cast.map((actor: any, i: number) => (
                                                <div key={i} className="flex-none bg-[#1A1A1D] px-4 py-2 rounded-lg border border-white/5 text-gray-300 text-sm font-medium hover:text-white hover:border-[#5D5FFF] transition-colors cursor-pointer">
                                                    {actor}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Modal;