import React from 'react';

const Logo: React.FC<{ className?: string }> = ({ className }) => (
    <div className={`relative flex items-center gap-2 ${className}`}>
        <svg 
            viewBox="0 0 24 24" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg" 
            className="w-full h-full max-w-[40px] max-h-[40px]"
        >
            {/* Neon Glow Filter */}
            <defs>
                <filter id="neon-glow" x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
                    <feMerge>
                        <feMergeNode in="coloredBlur"/>
                        <feMergeNode in="SourceGraphic"/>
                    </feMerge>
                </filter>
            </defs>
            
            {/* Hexagon Frame */}
            <path 
                d="M12 2L2 7V17L12 22L22 17V7L12 2Z" 
                stroke="#5D5FFF" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
                filter="url(#neon-glow)"
            />
            
            {/* Play Triangle */}
            <path 
                d="M9.5 8L16 12L9.5 16V8Z" 
                fill="white" 
                stroke="#5D5FFF" 
                strokeWidth="1"
                filter="url(#neon-glow)"
            />
        </svg>
        <span className="font-black text-white text-xl tracking-tighter hidden md:block">
            SAR<span className="text-[#5D5FFF]">MAX</span>
        </span>
    </div>
);

export default Logo;