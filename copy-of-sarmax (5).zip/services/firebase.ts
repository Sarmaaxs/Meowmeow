
import { UserAccount, Profile, Movie } from "../types";

const DB_KEYS = { USERS: 'sarmax_users_v1', SESSION: 'sarmax_session_v1' };

// Helper to read/write local DB
const getDB = () => JSON.parse(localStorage.getItem(DB_KEYS.USERS) || '{}');
const saveDB = (data: any) => localStorage.setItem(DB_KEYS.USERS, JSON.stringify(data));

export const authService = {
    // --- SIGNUP ---
    signup: async (email: string, pass: string, name: string): Promise<any> => {
        await new Promise(r => setTimeout(r, 800)); // Simulate network delay
        
        const users = getDB();
        const safeEmail = email.toLowerCase();
        
        // Check if exists
        const existing = Object.values(users).find((u: any) => u.email === safeEmail);
        if (existing) {
            return { ok: false, message: 'Email already exists.' };
        }

        // Generate OTP
        const otp = Math.floor(100000 + Math.random() * 900000).toString();
        console.log(`[Auth] Generated OTP for ${email}: ${otp}`); // For testing

        const newUser = {
            uid: 'user_' + Date.now(),
            email: safeEmail,
            name,
            password: pass,
            verified: false,
            otp_code: otp,
            plan: 'Free',
            profiles: [
                { id: 'p1', name: name, avatar: '#5D5FFF', watchlist: [] }
            ],
            createdAt: new Date().toISOString()
        };

        users[newUser.uid] = newUser;
        saveDB(users);

        // In a real app, we would trigger the email API here.
        // For this demo, we return the user to proceed to verification.
        return { ok: true, message: 'Verification code sent.', ...newUser };
    },

    // --- VERIFY OTP ---
    verifyCode: async (email: string, code: string): Promise<any> => {
        await new Promise(r => setTimeout(r, 600));
        
        const users = getDB();
        const user = Object.values(users).find((u: any) => u.email === email.toLowerCase()) as any;

        if (!user) return null;

        // Accept the generated OTP or a master code for testing
        if (user.otp_code === code || code === '123456') {
            user.verified = true;
            // Update DB
            users[user.uid] = user;
            saveDB(users);
            return user;
        }
        return null;
    },

    // --- LOGIN ---
    login: async (email: string, pass: string): Promise<any> => {
        await new Promise(r => setTimeout(r, 800));
        
        const users = getDB();
        const user = Object.values(users).find((u: any) => u.email === email.toLowerCase() && u.password === pass) as any;

        if (!user) return { ok: false, message: 'Invalid credentials.' };
        if (!user.verified) return { ok: false, message: 'Please verify your email first.' };

        return user;
    },

    // --- SESSION MANAGEMENT ---
    setSession: (user: any, profileId?: string) => {
        const activeProfile = user.profiles?.find((p: any) => p.id === profileId) || user.profiles?.[0];
        const sessionData = {
            user,
            activeProfile,
            token: 'mock_token_' + Date.now()
        };
        localStorage.setItem(DB_KEYS.SESSION, JSON.stringify(sessionData));
    },

    checkSession: async () => {
        const sessionStr = localStorage.getItem(DB_KEYS.SESSION);
        if (!sessionStr) return null;
        return JSON.parse(sessionStr);
    },

    logout: async () => {
        localStorage.removeItem(DB_KEYS.SESSION);
    },

    // --- FEATURES ---
    addToWatchlist: async (uid: string, profileId: string, movie: Movie) => {
        const users = getDB();
        if (users[uid]) {
            const user = users[uid];
            const profile = user.profiles.find((p: any) => p.id === profileId);
            if (profile) {
                const exists = profile.watchlist.find((m: Movie) => m.id === movie.id);
                if (!exists) {
                    profile.watchlist.unshift(movie);
                    saveDB(users);
                }
            }
        }
    },

    processPayment: async () => {
        await new Promise(r => setTimeout(r, 1500));
        return { ok: true };
    }
};
