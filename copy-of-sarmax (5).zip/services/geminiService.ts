import { GoogleGenAI, Type } from "@google/genai";
import { HomePageData, Movie } from "../types";
import { MOCK_DATA } from "../constants";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

// Fetch structured homepage data
export const fetchHomeContent = async (): Promise<HomePageData> => {
  // We return MOCK_DATA directly here to ensure the user sees the 
  // REAL curated movie posters defined in constants.ts, 
  // rather than AI-generated text which lacks image URLs.
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(MOCK_DATA);
    }, 500); // Small delay to simulate loading
  });
};

// Search
export const searchContent = async (query: string): Promise<Movie[]> => {
    const ai = getClient();
    // Fallback search if no API key
    if (!ai) {
        const allDocs = [...MOCK_DATA.categories[0].items, ...MOCK_DATA.categories[1].items];
        return allDocs.filter(m => m.title.toLowerCase().includes(query.toLowerCase()));
    }

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Search query: "${query}". Return a list of 6 real movies/TV shows matching this.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            id: { type: Type.STRING },
                            title: { type: Type.STRING },
                            description: { type: Type.STRING },
                            rating: { type: Type.NUMBER },
                            year: { type: Type.NUMBER },
                            genre: { type: Type.ARRAY, items: { type: Type.STRING } },
                            match: { type: Type.NUMBER },
                        }
                    }
                }
            }
        });
        
        const text = response.text;
        if (!text) return [];
        return JSON.parse(text) as Movie[];
    } catch (e) {
        return [];
    }
}