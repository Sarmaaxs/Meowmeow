
import React from 'react';
import { useAuth } from '../context/AuthContext';
import { LogOut, User, Bell, Shield, Smartphone, CreditCard } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';

const SettingsPage: React.FC = () => {
    const { user, logOut } = useAuth();
    const navigate = useNavigate();
    const currentPlan = localStorage.getItem('sarmax_plan') || 'Free';

    const handleLogout = async () => {
        await logOut();
        navigate('/login');
    };

    return (
        <div className="min-h-screen bg-[#0f1014] pb-24 pt-8 px-4">
            <h1 className="text-3xl font-bold text-white mb-8">Settings</h1>
            
            {user && (
                <div className="bg-[#1a1a1a] rounded-xl p-4 mb-6 flex items-center gap-4 border border-gray-800">
                    <div className="w-12 h-12 rounded-full bg-emerald-600 flex items-center justify-center text-white font-bold text-xl">
                        {user.email?.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1">
                        <h2 className="text-white font-bold">{user.email}</h2>
                        <p className="text-gray-500 text-sm">Member since 2024</p>
                    </div>
                    <Link to="/plans" className="text-xs bg-emerald-600/20 text-emerald-500 px-3 py-1 rounded-full font-bold border border-emerald-600/50">
                        {currentPlan === 'Free' ? 'UPGRADE' : 'CHANGE PLAN'}
                    </Link>
                </div>
            )}

            <div className="space-y-4">
                <Section title="Membership">
                    <div onClick={() => navigate('/plans')} className="flex items-center gap-3 p-4 border-b border-gray-800 hover:bg-gray-800 cursor-pointer transition-colors">
                         <CreditCard className="w-5 h-5 text-emerald-500" />
                         <div className="flex-1">
                            <span className="text-white font-medium block">Manage Plan</span>
                            <span className="text-xs text-emerald-400 font-bold">Current: {currentPlan} Plan</span>
                         </div>
                    </div>
                </Section>

                <Section title="General">
                    <Item icon={User} label="Account" />
                    <Item icon={Bell} label="Notifications" />
                    <Item icon={Smartphone} label="App Settings" />
                </Section>

                <Section title="Support">
                    <Item icon={Shield} label="Privacy Policy" />
                    <Item icon={Shield} label="Help Center" />
                </Section>
                
                {user ? (
                    <button 
                        onClick={handleLogout}
                        className="w-full bg-[#1a1a1a] p-4 rounded-xl flex items-center gap-3 text-red-400 font-bold border border-gray-800 mt-8 hover:bg-gray-900 transition-colors"
                    >
                        <LogOut className="w-5 h-5" /> Log Out
                    </button>
                ) : (
                     <button 
                        onClick={() => navigate('/login')}
                        className="w-full bg-emerald-600 p-4 rounded-xl flex items-center justify-center gap-3 text-white font-bold border border-transparent mt-8 hover:bg-emerald-700 transition-colors"
                    >
                        Log In
                    </button>
                )}
            </div>
        </div>
    );
};

const Section: React.FC<{title: string, children: React.ReactNode}> = ({title, children}) => (
    <div>
        <h3 className="text-gray-500 text-sm font-bold uppercase mb-2 ml-2">{title}</h3>
        <div className="bg-[#1a1a1a] rounded-xl overflow-hidden border border-gray-800">
            {children}
        </div>
    </div>
);

const Item: React.FC<{icon: any, label: string}> = ({icon: Icon, label}) => (
    <div className="flex items-center gap-3 p-4 border-b border-gray-800 last:border-none hover:bg-gray-800 cursor-pointer transition-colors">
        <Icon className="w-5 h-5 text-gray-400" />
        <span className="text-white font-medium flex-1">{label}</span>
    </div>
);

export default SettingsPage;
