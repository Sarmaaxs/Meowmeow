
import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import { useAuth } from '../context/AuthContext';
import { Movie } from '../types';
import Modal from '../components/Modal';
import SmartImage from '../components/SmartImage';
import { getPosterUrl } from '../constants';
import { Play, Film } from 'lucide-react';

const Watchlist: React.FC = () => {
    const { activeProfile } = useAuth();
    const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);

    return (
        <div className="min-h-screen bg-[#0D0D0F] text-white pb-24">
            <Navbar isScrolled={true} />
            <div className="pt-24 px-4 md:px-12 max-w-7xl mx-auto">
                <h1 className="text-3xl font-black text-white mb-8 flex items-center gap-2">
                    <span className="w-1 h-8 bg-[#5D5FFF] rounded-full"></span>
                    My List
                </h1>

                {activeProfile?.watchlist && activeProfile.watchlist.length > 0 ? (
                    <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                        {activeProfile.watchlist.map((movie: Movie) => (
                            <div key={movie.id} className="group relative bg-[#1A1A1D] rounded-xl overflow-hidden cursor-pointer hover:scale-[1.02] transition-all duration-200 shadow-md hover:shadow-[0_0_20px_rgba(93,95,255,0.2)]" onClick={() => setSelectedMovie(movie)}>
                                <div className="aspect-[2/3] w-full relative bg-[#222]">
                                    <SmartImage src={getPosterUrl(movie)} alt={movie.title} className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity" referrerPolicy="no-referrer" />
                                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/50">
                                        <Play className="fill-white w-8 h-8 text-white drop-shadow-lg" />
                                    </div>
                                    <div className="absolute top-2 right-2 bg-[#5D5FFF] text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-md">HD</div>
                                </div>
                                <div className="p-3">
                                    <h3 className="font-bold text-white text-sm truncate">{movie.title}</h3>
                                    <div className="flex items-center justify-between mt-1 text-xs text-gray-400">
                                        <span>{movie.year}</span>
                                        <span className="text-[#5D5FFF] font-bold">{movie.rating}</span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center py-32 text-gray-500 border-2 border-dashed border-gray-800 rounded-2xl">
                        <Film className="w-16 h-16 mb-4 opacity-20" />
                        <p className="text-lg font-medium">Your list is empty</p>
                        <p className="text-sm mt-2">Add movies and shows to keep track of what you want to watch.</p>
                    </div>
                )}
            </div>
            {selectedMovie && <Modal movie={selectedMovie} onClose={() => setSelectedMovie(null)} />}
        </div>
    );
};
export default Watchlist;
