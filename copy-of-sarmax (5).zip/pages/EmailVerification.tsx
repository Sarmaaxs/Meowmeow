import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Mail, ArrowRight, RefreshCw } from 'lucide-react';
import Logo from '../components/Logo';

const EmailVerification: React.FC = () => {
    const [code, setCode] = useState(['','','','','','']);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const { verifyEmail, resendVerification, user } = useAuth();
    const navigate = useNavigate();

    useEffect(() => {
        if(!user) navigate('/signup');
    }, [user, navigate]);

    const handleChange = (index: number, value: string) => {
        if(isNaN(Number(value))) return;
        const newCode = [...code];
        newCode[index] = value;
        setCode(newCode);
        
        // Auto focus next input
        if (value && index < 5) {
            const nextInput = document.getElementById(`code-${index + 1}`);
            nextInput?.focus();
        }
    };

    const handleVerify = async () => {
        const fullCode = code.join('');
        if(fullCode.length !== 6) {
            setError("Please enter complete 6-digit code");
            return;
        }
        setLoading(true);
        setError('');
        
        try {
            const success = await verifyEmail(fullCode);
            if(success) {
                navigate('/profile'); // Or success page
            } else {
                setError("Invalid code. Please try again.");
            }
        } catch(e) {
            setError("Verification failed.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-[#0D0D0F] flex items-center justify-center p-4">
             <div className="w-full max-w-md bg-[#151517] border border-white/5 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
                 <div className="flex justify-center mb-6">
                    <div className="w-16 h-16 rounded-full bg-[#5D5FFF]/10 flex items-center justify-center">
                        <Mail className="w-8 h-8 text-[#5D5FFF]" />
                    </div>
                 </div>
                 
                 <h2 className="text-2xl font-black text-center text-white mb-2">Check your email</h2>
                 <p className="text-center text-gray-400 text-sm mb-8">We sent a verification code to <span className="text-white font-bold">{user?.email}</span></p>

                 <div className="flex justify-between gap-2 mb-8">
                    {code.map((digit, idx) => (
                        <input
                            key={idx}
                            id={`code-${idx}`}
                            type="text"
                            maxLength={1}
                            value={digit}
                            onChange={(e) => handleChange(idx, e.target.value)}
                            className="w-12 h-14 bg-[#0D0D0F] border border-gray-700 rounded-xl text-center text-2xl font-bold text-white focus:border-[#5D5FFF] focus:ring-1 focus:ring-[#5D5FFF] outline-none transition-all"
                        />
                    ))}
                 </div>

                 {error && <p className="text-red-400 text-xs font-bold text-center mb-4">{error}</p>}

                 <button 
                    onClick={handleVerify}
                    disabled={loading}
                    className="w-full bg-[#5D5FFF] hover:bg-[#4b4dcc] py-4 rounded-xl font-bold text-white text-sm transition-all shadow-lg hover:shadow-[#5D5FFF]/40 mb-6 flex items-center justify-center gap-2"
                 >
                    {loading ? "Verifying..." : <>Verify Email <ArrowRight className="w-4 h-4" /></>}
                 </button>

                 <div className="text-center">
                     <button onClick={resendVerification} className="text-gray-500 text-xs hover:text-white flex items-center justify-center gap-2 w-full">
                         <RefreshCw className="w-3 h-3" /> Resend Code
                     </button>
                 </div>
             </div>
        </div>
    );
};

export default EmailVerification;