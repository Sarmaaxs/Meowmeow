import React, { useState, useEffect } from 'react';
import { Search as SearchIcon, X } from 'lucide-react';
import Navbar from '../components/Navbar';
import Modal from '../components/Modal';
import { Movie } from '../types';
import { MOCK_DATA, EXTRA_SEARCH_DATA } from '../constants';
import Poster from '../components/Poster';

const SearchPage: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Movie[]>([]);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const trimmed = query.toLowerCase().trim();
    
    if (!trimmed) {
        setResults([]);
        return;
    }

    setLoading(true);
    
    const timer = setTimeout(() => {
        // Combine Main Data + Extra Search Data
        const allMovies = [
            ...MOCK_DATA.categories.flatMap(c => c.items),
            MOCK_DATA.hero as Movie,
            ...EXTRA_SEARCH_DATA
        ];
        
        // Remove duplicates
        const uniqueMovies = Array.from(new Map(allMovies.map(item => [item.id, item])).values());

        const filtered = uniqueMovies.filter(m => 
            m.title.toLowerCase().includes(trimmed) || 
            m.overview?.toLowerCase().includes(trimmed) ||
            m.year?.toString().includes(trimmed)
        );
        
        setResults(filtered);
        setLoading(false);
    }, 300);

    return () => clearTimeout(timer);
  }, [query]);

  return (
    <div className="min-h-screen bg-[#0D0D0F] text-white">
      <Navbar isScrolled={true} />
      
      <div className="pt-24 px-4 md:px-12 max-w-7xl mx-auto">
        <div className="relative mb-8 group">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                {loading ? (
                    <div className="w-5 h-5 border-2 border-[#5D5FFF] border-t-transparent rounded-full animate-spin"></div>
                ) : (
                    <SearchIcon className="h-5 w-5 text-gray-500 group-focus-within:text-[#5D5FFF] transition-colors" />
                )}
            </div>
            <input 
                type="text"
                placeholder="Search titles, people, genres..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full pl-12 pr-10 py-4 bg-[#1A1A1D] border border-gray-800 rounded-xl text-lg focus:outline-none focus:border-[#5D5FFF] focus:ring-1 focus:ring-[#5D5FFF] transition-all placeholder-gray-600 font-medium shadow-lg"
                autoFocus
            />
            {query && (
                <button onClick={() => setQuery('')} className="absolute inset-y-0 right-4 flex items-center text-gray-500 hover:text-white">
                    <X className="w-5 h-5" />
                </button>
            )}
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 pb-24">
            {results.map((movie) => (
                <Poster 
                    key={movie.id}
                    src={movie.poster_path || movie.poster || movie.image}
                    title={movie.title}
                    year={movie.year}
                    rating={movie.rating || movie.vote_average}
                    onClick={() => setSelectedMovie(movie)}
                />
            ))}
        </div>
        
        {!loading && results.length === 0 && query && (
            <div className="text-center py-20 text-gray-500">
                <p>No matches found for "{query}"</p>
            </div>
        )}

        {!query && (
             <div className="flex flex-col items-center justify-center py-20 text-gray-700">
                <SearchIcon className="w-16 h-16 mb-4 opacity-20" />
                <p className="text-xl font-medium text-gray-600">Explore the massive library</p>
             </div>
        )}
      </div>

      {selectedMovie && (
        <Modal movie={selectedMovie} onClose={() => setSelectedMovie(null)} />
      )}
    </div>
  );
};

export default SearchPage;