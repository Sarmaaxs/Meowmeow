import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import { useAuth } from '../context/AuthContext';
import { Download, Settings, User, LogOut, Trash2, Play, Film, HardDrive, WifiOff } from 'lucide-react';
import SmartImage from '../components/SmartImage';
import { getPosterUrl } from '../constants';

const Profile: React.FC = () => {
    const { user, activeProfile, logOut } = useAuth();
    const [activeTab, setActiveTab] = useState<'watchlist' | 'downloads' | 'settings'>('watchlist');

    // Mock Downloads Data for UI visualization
    const downloads = [
        { id: '1', title: 'Dune: Part Two', size: '2.4 GB', progress: 100, status: 'completed' },
        { id: '2', title: 'The Bear S01E01', size: '850 MB', progress: 45, status: 'downloading' }
    ];

    return (
        <div className="min-h-screen bg-[#0D0D0F] pb-24">
            <Navbar isScrolled={true} />
            <div className="pt-24 px-4 md:px-12 max-w-6xl mx-auto">
                {/* Header with Profile Info */}
                <div className="flex items-center gap-6 mb-12">
                     <div className="w-24 h-24 rounded-full border-4 border-[#5D5FFF] overflow-hidden shadow-2xl shadow-[#5D5FFF]/20">
                         {/* Dynamic Avatar */}
                         <div className="w-full h-full flex items-center justify-center text-4xl font-bold text-white" style={{ backgroundColor: activeProfile?.avatar || '#5D5FFF' }}>
                            {activeProfile?.name?.charAt(0).toUpperCase()}
                         </div>
                     </div>
                     <div>
                        <h1 className="text-3xl font-black text-white mb-1">{activeProfile?.name}</h1>
                        <p className="text-gray-400 text-sm mb-2">{user?.email}</p>
                        <div className="flex gap-2">
                            <span className="bg-[#5D5FFF]/20 text-[#5D5FFF] text-xs px-2 py-1 rounded font-bold border border-[#5D5FFF]/50 uppercase">{user?.plan || 'Free'} Plan</span>
                        </div>
                     </div>
                </div>

                {/* Navigation Tabs */}
                <div className="flex gap-8 border-b border-gray-800 mb-8 overflow-x-auto">
                    {[
                        { id: 'watchlist', label: `My List (${activeProfile?.watchlist?.length || 0})` },
                        { id: 'downloads', label: 'Downloads' },
                        { id: 'settings', label: 'Settings' }
                    ].map(tab => (
                        <button 
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id as any)}
                            className={`pb-4 text-sm font-bold uppercase tracking-wider border-b-2 transition-colors whitespace-nowrap ${activeTab === tab.id ? 'border-[#5D5FFF] text-[#5D5FFF]' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>

                {/* Tab Content */}
                {activeTab === 'watchlist' && (
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                        {activeProfile?.watchlist && activeProfile.watchlist.length > 0 ? (
                            activeProfile.watchlist.map(item => (
                                <div key={item.id} className="relative aspect-[2/3] rounded-xl overflow-hidden group cursor-pointer bg-[#1A1A1D]">
                                    <SmartImage src={getPosterUrl(item)} alt={item.title} className="w-full h-full" />
                                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                        <Play className="w-10 h-10 text-white fill-white drop-shadow-lg" />
                                    </div>
                                    <div className="absolute bottom-0 left-0 w-full p-2 bg-gradient-to-t from-black to-transparent">
                                        <p className="text-white text-xs font-bold truncate">{item.title}</p>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="col-span-full py-12 text-center text-gray-500 border border-dashed border-gray-800 rounded-xl">
                                <Film className="w-12 h-12 mx-auto mb-4 opacity-20" />
                                <p>Your list is empty. Add movies to watch them later.</p>
                            </div>
                        )}
                    </div>
                )}

                {activeTab === 'downloads' && (
                    <div className="space-y-4">
                         {downloads.map(dl => (
                             <div key={dl.id} className="bg-[#1A1A1D] p-4 rounded-xl border border-white/5 flex items-center gap-4">
                                 <div className="w-12 h-16 bg-gray-800 rounded overflow-hidden">
                                     {/* Mock Poster */}
                                     <div className="w-full h-full bg-gray-700 animate-pulse"></div> 
                                 </div>
                                 <div className="flex-1">
                                     <h4 className="font-bold text-white text-sm">{dl.title}</h4>
                                     <p className="text-xs text-gray-500">{dl.size} • {dl.status === 'completed' ? 'Ready to watch' : 'Downloading...'}</p>
                                     {dl.status === 'downloading' && (
                                         <div className="w-full h-1 bg-gray-800 rounded-full mt-2 overflow-hidden">
                                             <div className="h-full bg-[#5D5FFF]" style={{width: `${dl.progress}%`}}></div>
                                         </div>
                                     )}
                                 </div>
                                 <div className="flex items-center gap-2">
                                     {dl.status === 'completed' ? (
                                         <button className="p-2 bg-[#5D5FFF]/20 text-[#5D5FFF] rounded-full hover:bg-[#5D5FFF] hover:text-white transition-colors"><Play className="w-4 h-4 fill-current" /></button>
                                     ) : (
                                         <button className="p-2 bg-gray-800 text-gray-400 rounded-full"><WifiOff className="w-4 h-4" /></button>
                                     )}
                                     <button className="p-2 hover:bg-red-500/20 text-gray-500 hover:text-red-500 rounded-full transition-colors"><Trash2 className="w-4 h-4" /></button>
                                 </div>
                             </div>
                         ))}
                         <div className="bg-[#1A1A1D]/50 p-4 rounded-xl flex items-center gap-3 text-xs text-gray-400">
                             <HardDrive className="w-4 h-4" />
                             <span>Storage Used: 3.2 GB / 10 GB (Standard Plan)</span>
                         </div>
                    </div>
                )}

                {activeTab === 'settings' && (
                    <div className="grid md:grid-cols-2 gap-6">
                        <div className="bg-[#1A1A1D] p-6 rounded-xl border border-white/5">
                            <h3 className="font-bold text-white mb-4 flex items-center gap-2"><User className="w-4 h-4" /> Account Details</h3>
                            <div className="space-y-4">
                                <div>
                                    <label className="text-xs text-gray-500 block mb-1">Email</label>
                                    <input type="text" value={user?.email} disabled className="w-full bg-[#0D0D0F] border border-gray-800 rounded-lg p-3 text-gray-400 text-sm" />
                                </div>
                                <div>
                                    <label className="text-xs text-gray-500 block mb-1">Current Plan</label>
                                    <div className="flex gap-2">
                                        <input type="text" value={user?.plan} disabled className="w-full bg-[#0D0D0F] border border-gray-800 rounded-lg p-3 text-gray-400 text-sm" />
                                        <button className="px-4 bg-[#5D5FFF]/20 text-[#5D5FFF] rounded-lg text-xs font-bold whitespace-nowrap hover:bg-[#5D5FFF] hover:text-white transition-colors">Manage</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="bg-[#1A1A1D] p-6 rounded-xl border border-white/5 flex flex-col justify-between">
                             <div>
                                <h3 className="font-bold text-white mb-4 flex items-center gap-2"><Settings className="w-4 h-4" /> Preferences</h3>
                                <div className="space-y-3">
                                    <div className="flex items-center justify-between p-3 bg-[#0D0D0F] rounded-lg">
                                        <span className="text-sm text-gray-300">Autoplay Next Episode</span>
                                        <div className="w-10 h-5 bg-[#5D5FFF] rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full"></div></div>
                                    </div>
                                    <div className="flex items-center justify-between p-3 bg-[#0D0D0F] rounded-lg">
                                        <span className="text-sm text-gray-300">Data Saver Mode</span>
                                        <div className="w-10 h-5 bg-gray-700 rounded-full relative cursor-pointer"><div className="absolute left-1 top-1 w-3 h-3 bg-white rounded-full"></div></div>
                                    </div>
                                </div>
                             </div>

                             <button onClick={logOut} className="mt-6 w-full py-3 border border-red-500/50 text-red-500 rounded-xl font-bold hover:bg-red-500/10 transition-colors flex items-center justify-center gap-2">
                                <LogOut className="w-4 h-4" /> Sign Out of All Devices
                             </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Profile;
