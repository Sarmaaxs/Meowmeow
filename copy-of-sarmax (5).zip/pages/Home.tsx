import React, { useEffect, useState } from 'react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import Row from '../components/Row';
import Modal from '../components/Modal';
import { fetchHomeContent } from '../services/geminiService';
import { HomePageData, Movie } from '../types';
import { MOCK_DATA } from '../constants';
import { useAuth } from '../context/AuthContext';

const Home: React.FC = () => {
  const [data, setData] = useState<HomePageData>(MOCK_DATA);
  const [loading, setLoading] = useState(true);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const { activeProfile } = useAuth();

  useEffect(() => {
    const loadData = async () => {
      try {
        const fetchedData = await fetchHomeContent();
        setData(fetchedData);
      } catch (err) {
        setData(MOCK_DATA);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 0) setIsScrolled(true);
      else setIsScrolled(false);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (loading) {
     return (
        <div className="h-screen w-full bg-[#0D0D0F] flex items-center justify-center">
           <div className="relative w-16 h-16">
               <div className="absolute top-0 left-0 w-full h-full border-4 border-[#5D5FFF]/20 rounded-full"></div>
               <div className="absolute top-0 left-0 w-full h-full border-4 border-[#5D5FFF] rounded-full border-t-transparent animate-spin"></div>
           </div>
        </div>
     );
  }

  return (
    <div className="bg-[#0D0D0F] min-h-screen pb-24">
      <Navbar isScrolled={isScrolled} />
      
      <Hero movie={data.hero} onMoreInfo={setSelectedMovie} />
      
      <div className="-mt-20 relative z-20 pl-0 space-y-2">
         {/* Watchlist Row - Only shows if items exist */}
         {activeProfile?.watchlist && activeProfile.watchlist.length > 0 && (
             <Row title={`My List`} items={activeProfile.watchlist} onMovieClick={setSelectedMovie} />
         )}
         
         {data.categories.map((category, index) => (
            <Row 
              key={index} 
              title={category.title} 
              items={category.items} 
              onMovieClick={setSelectedMovie} 
            />
         ))}
         
         <Row 
            title="Continue Watching" 
            items={MOCK_DATA.categories[0].items.slice().reverse()} 
            onMovieClick={setSelectedMovie} 
         />
      </div>

      {selectedMovie && (
        <Modal movie={selectedMovie} onClose={() => setSelectedMovie(null)} />
      )}
    </div>
  );
};

export default Home;