import { Match } from "../types";

// Seed Data
const INITIAL_MATCHES: Match[] = [
    { 
        id: 1, home: 'Arsenal', away: 'Liverpool', time: 'LIVE', score: '1 - 1', league: 'Premier League', status: 'LIVE', minute: 34,
        possession: [48, 52],
        events: [{time: '12\'', text: 'Goal (Saka)', team: 'home', type: 'goal'}, {time: '28\'', text: 'Goal (Nunez)', team: 'away', type: 'goal'}]
    },
    { 
        id: 2, home: 'Barcelona', away: 'Real Madrid', time: 'LIVE', score: '0 - 0', league: 'La Liga', status: 'LIVE', minute: 12,
        possession: [60, 40],
        events: []
    },
    { 
        id: 3, home: 'Man City', away: 'Chelsea', time: '19:45', score: '0 - 0', league: 'Premier League', status: 'UPCOMING', minute: 0,
        possession: [50, 50],
        events: []
    }
];

// Event Generator Logic
const tickMatch = (match: Match): Match => {
    if (match.status !== 'LIVE') return match;

    let newMinute = match.minute + 1;
    let newEvents = [...match.events];
    let newScoreStr = match.score;

    // Random Event Chance (Goals, Cards)
    if (Math.random() > 0.96) { 
        const isGoal = Math.random() > 0.4; // 60% chance it's a goal if event triggers
        const isHome = Math.random() > 0.5;
        
        if (isGoal) {
            const scores = match.score.split(' - ').map(Number);
            if(isHome) scores[0]++; else scores[1]++;
            newScoreStr = `${scores[0]} - ${scores[1]}`;
            newEvents.unshift({
                time: `${newMinute}'`,
                text: `GOAL! ${isHome ? match.home : match.away}`,
                team: isHome ? 'home' : 'away',
                type: 'goal'
            });
        } else {
             newEvents.unshift({
                time: `${newMinute}'`,
                text: `Yellow Card`,
                team: isHome ? 'home' : 'away',
                type: 'card'
            });
        }
    }

    return {
        ...match,
        minute: newMinute > 90 ? 90 : newMinute,
        score: newScoreStr,
        events: newEvents
    };
};

export class SportsEngine {
    private matches: Match[] = INITIAL_MATCHES;
    private subscribers: ((matches: Match[]) => void)[] = [];
    private interval: any;

    constructor() {
        this.start();
    }

    private start() {
        // "WebSocket" Heartbeat - Updates every second
        this.interval = setInterval(() => {
            this.matches = this.matches.map(tickMatch);
            this.notify();
        }, 1000); 
    }

    subscribe(cb: (matches: Match[]) => void) {
        this.subscribers.push(cb);
        cb(this.matches); // Initial state
        return () => {
            this.subscribers = this.subscribers.filter(s => s !== cb);
        };
    }

    private notify() {
        this.subscribers.forEach(cb => cb(this.matches));
    }
}

export const sportsService = new SportsEngine();