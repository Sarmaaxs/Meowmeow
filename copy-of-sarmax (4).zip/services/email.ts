
// Hybrid Email Service
// Connects to server.js for real SMTP sending.
// Falls back to console log if server is not reachable (for dev safety).

const API_URL = (import.meta as any).env?.VITE_API_BASE || 'http://localhost:4000';

export const sendVerificationCode = async (email: string, code: string) => {
    try {
        console.log(`[Email] Attempting to send verification to ${email}...`);
        
        // This is handled by the signup route in server.js usually, 
        // but if we need a manual resend:
        // For now, we assume the signup endpoint handled the initial send.
        return true;
    } catch (e) {
        console.error("Email send failed", e);
        return false;
    }
};

export const sendWelcomeEmail = async (email: string) => {
    try {
        console.log(`[Email] Sending welcome to ${email}...`);
        // The /api/auth/verify endpoint in server.js handles this automatically
        return true;
    } catch (e) {
        console.warn("Welcome email trigger failed", e);
        return false;
    }
};

// Test helper
export const testEmailConnection = async () => {
    try {
        await fetch(`${API_URL}/api/health`);
        return true;
    } catch {
        console.warn("Backend not reachable. Using simulation mode.");
        return false;
    }
}
