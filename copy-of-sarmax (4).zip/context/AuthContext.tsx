
import React, { createContext, useContext, useEffect, useState } from 'react';
import { authService } from '../services/firebase';
import { UserAccount, Profile, Movie } from '../types';

interface AuthContextType {
  user: UserAccount | null;
  activeProfile: Profile | null;
  loading: boolean;
  signUp: (email: string, pass: string, name: string) => Promise<void>;
  logIn: (email: string, pass: string) => Promise<void>;
  logOut: () => Promise<void>;
  selectProfile: (profileId: string) => void;
  addToWatchlist: (movie: Movie) => Promise<void>;
  verifyEmail: (code: string) => Promise<boolean>;
  resendVerification: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserAccount | null>(null);
  const [activeProfile, setActiveProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  // Restore session on load
  useEffect(() => {
    const init = async () => {
        try {
            const session = await authService.checkSession();
            if (session && session.user) {
                setUser(session.user);
                setActiveProfile(session.activeProfile);
            }
        } catch (e) {
            console.error("Session restore failed", e);
        } finally {
            setLoading(false);
        }
    };
    init();
  }, []);

  const signUp = async (email: string, pass: string, name: string) => {
    const response = await authService.signup(email, pass, name);
    if (response.ok === false) {
        throw new Error(response.message || 'Signup failed');
    }
    // Temporarily set user to allow navigation to Verification page
    setUser(response); 
  };

  const logIn = async (email: string, pass: string) => {
    const response = await authService.login(email, pass);
    if (response.ok === false) {
        throw new Error(response.message);
    }
    setUser(response);
    const profile = response.profiles[0];
    setActiveProfile(profile);
    authService.setSession(response, profile.id);
  };

  const verifyEmail = async (code: string) => {
      if (!user) return false;
      const verifiedUser = await authService.verifyCode(user.email, code);
      if (verifiedUser) {
          setUser(verifiedUser);
          const profile = verifiedUser.profiles[0];
          setActiveProfile(profile);
          authService.setSession(verifiedUser, profile.id);
          return true;
      }
      return false;
  };

  const resendVerification = async () => {
      // Mock resend
      if (user) {
          console.log(`[Auth] Resending code to ${user.email}...`);
          alert(`New code sent to ${user.email} (Check Console)`);
      }
  };

  const logOut = async () => {
    await authService.logout();
    setUser(null);
    setActiveProfile(null);
  };

  const selectProfile = (profileId: string) => {
      if (user) {
          const profile = user.profiles.find(p => p.id === profileId);
          if (profile) {
              setActiveProfile(profile);
              authService.setSession(user, profileId);
          }
      }
  };

  const addToWatchlist = async (movie: Movie) => {
      if (user && activeProfile) {
          await authService.addToWatchlist(user.uid, activeProfile.id, movie);
          // Optimistic UI update
          const updatedWatchlist = [movie, ...activeProfile.watchlist.filter(m => m.id !== movie.id)];
          setActiveProfile({ ...activeProfile, watchlist: updatedWatchlist });
      }
  };

  return (
    <AuthContext.Provider value={{ user, activeProfile, loading, signUp, logIn, logOut, selectProfile, addToWatchlist, verifyEmail, resendVerification }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
