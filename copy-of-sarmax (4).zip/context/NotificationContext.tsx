import React, { createContext, useContext, useState, useCallback } from 'react';
import { Notification } from '../types';

interface NotificationContextType {
    notifications: Notification[];
    unreadCount: number;
    addNotification: (title: string, message: string, type?: Notification['type']) => void;
    markAsRead: (id: string) => void;
    clearAll: () => void;
}

const NotificationContext = createContext<NotificationContextType | null>(null);

export const useNotifications = () => {
    const context = useContext(NotificationContext);
    if (!context) throw new Error('useNotifications must be used within NotificationProvider');
    return context;
};

export const NotificationProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
    const [notifications, setNotifications] = useState<Notification[]>([]);

    const addNotification = useCallback((title: string, message: string, type: Notification['type'] = 'info') => {
        const newNotif: Notification = {
            id: Date.now().toString(),
            title,
            message,
            type,
            read: false,
            date: new Date()
        };
        setNotifications(prev => [newNotif, ...prev]);
        
        // Auto-remove toast-style notifications after 5s if needed (optional logic)
    }, []);

    const markAsRead = (id: string) => {
        setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    };

    const clearAll = () => {
        setNotifications([]);
    };

    const unreadCount = notifications.filter(n => !n.read).length;

    return (
        <NotificationContext.Provider value={{ notifications, unreadCount, addNotification, markAsRead, clearAll }}>
            {children}
            
            {/* Global Toast Container */}
            <div className="fixed top-20 right-4 z-[100] flex flex-col gap-2 pointer-events-none">
                {notifications.slice(0, 3).map(n => !n.read && (
                    <div key={n.id} className="bg-[#1A1A1D]/90 backdrop-blur border border-[#5D5FFF]/30 p-4 rounded-xl shadow-xl w-80 animate-slide-up pointer-events-auto flex items-start gap-3">
                        <div className={`w-2 h-2 rounded-full mt-2 flex-none ${n.type === 'success' ? 'bg-green-500' : n.type === 'error' ? 'bg-red-500' : 'bg-[#5D5FFF]'}`} />
                        <div>
                            <h4 className="text-white text-sm font-bold">{n.title}</h4>
                            <p className="text-gray-400 text-xs">{n.message}</p>
                        </div>
                    </div>
                ))}
            </div>
        </NotificationContext.Provider>
    );
};