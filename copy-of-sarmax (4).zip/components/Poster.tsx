import React, { useState } from 'react';
import { Play } from 'lucide-react';

export function fixPosterURL(url: string | undefined | null) {
  if (!url) return null;

  // Convert protocol-less URLs => absolute
  if (url.startsWith('//')) return 'https:' + url;

  // If relative path, prepend TMDB base
  if (url.startsWith('/'))
    return 'https://image.tmdb.org/t/p/w500' + url;

  // If no http, treat as filename/TMDB path
  if (!url.startsWith('http'))
    return 'https://image.tmdb.org/t/p/w500/' + url;

  return url;
}

interface PosterProps {
    src?: string;
    title: string;
    className?: string;
    onClick?: () => void;
    showTitle?: boolean;
    rating?: number;
    year?: number;
}

const Poster: React.FC<PosterProps> = ({ src, title, className, onClick, showTitle = true, rating, year }) => {
    const [error, setError] = useState(false);
    const fixedSrc = fixPosterURL(src);
    const fallback = 'https://via.placeholder.com/300x450/1a1a1d/5d5fff?text=No+Image';

    // Rule 3: Hide Broken Posters Entirely (if URL is missing)
    if (!fixedSrc) return null;

    // If error occurred during load, we can either show fallback or hide.
    // Prompt Rule 3 says "If a poster is missing OR fails to load, don’t show the item at all."
    // But keeping a fallback is usually better UX than shifting layout. 
    // However, complying with "Hide Broken Posters" strict rule:
    if (error) return null; 

    return (
        <div 
            className={`group relative bg-[#1A1A1D] rounded-xl overflow-hidden cursor-pointer hover:scale-[1.02] transition-all duration-200 shadow-md hover:shadow-[0_0_20px_rgba(93,95,255,0.2)] flex flex-col ${className}`}
            onClick={onClick}
        >
            {/* Aspect Ratio Container 2:3 */}
            <div className="relative w-full" style={{ aspectRatio: '2/3' }}>
                <img
                    src={fixedSrc}
                    alt={title}
                    loading="lazy"
                    className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity"
                    onError={(e) => {
                        // Option A: Hide it
                        setError(true);
                        // Option B (Fallback):
                        // e.currentTarget.src = fallback;
                    }}
                />
                
                {/* Hover Play Overlay */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/50">
                    <Play className="fill-white w-8 h-8 text-white drop-shadow-lg" />
                </div>
                
                {/* HD Badge */}
                <div className="absolute top-2 right-2 bg-[#5D5FFF] text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-md">
                    HD
                </div>
            </div>

            {/* Title Section */}
            {showTitle && (
                <div className="p-3 flex-1 flex flex-col justify-end">
                    <h3 className="font-bold text-white text-sm truncate">{title}</h3>
                    {(year || rating) && (
                        <div className="flex items-center justify-between mt-1 text-xs text-gray-400">
                            <span>{year}</span>
                            {rating && <span className="text-[#5D5FFF] font-bold">{rating}</span>}
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default Poster;