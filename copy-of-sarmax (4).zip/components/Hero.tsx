import React from 'react';
import { Play, Info } from 'lucide-react';
import { Movie } from '../types';
import { resolveBackdrop } from '../utils';
import SmartImage from './SmartImage';

interface HeroProps {
    movie: Movie | null;
    onMoreInfo: (m: Movie) => void;
}

const Hero: React.FC<HeroProps> = ({ movie, onMoreInfo }) => {
    if (!movie) return <div className="h-[56.25vw] bg-[#141414]" />;

    return (
        <div className="relative h-[56.25vw] max-h-[85vh] min-h-[500px] w-full">
            <div className="absolute inset-0">
                <SmartImage 
                    src={resolveBackdrop(movie)} 
                    alt={movie.title} 
                    className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-[#141414]/60 via-transparent to-transparent" />
                <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-[#141414] to-transparent" />
            </div>

            <div className="absolute top-[30%] left-[4%] max-w-[40%] z-10">
                <h1 className="text-4xl md:text-6xl font-black text-white drop-shadow-lg mb-4 leading-none">
                    {movie.title}
                </h1>
                <p className="text-lg text-white drop-shadow-md mb-6 line-clamp-3 font-medium">
                    {movie.overview}
                </p>
                
                <div className="flex items-center gap-3">
                    <button className="flex items-center gap-2 px-6 py-2 bg-white text-black rounded font-bold text-xl hover:bg-white/80 transition-colors">
                        <Play className="fill-black w-6 h-6" /> Play
                    </button>
                    <button 
                        onClick={() => onMoreInfo(movie)}
                        className="flex items-center gap-2 px-6 py-2 bg-[rgba(109,109,110,0.7)] text-white rounded font-bold text-xl hover:bg-[rgba(109,109,110,0.4)] transition-colors"
                    >
                        <Info className="w-6 h-6" /> More Info
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Hero;