import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Movie } from '../types';
import { useNavigate } from 'react-router-dom';
import Poster from './Poster';

interface RowProps {
    title: string;
    items: Movie[];
    onMovieClick: (m: Movie) => void;
}

const Row: React.FC<RowProps> = ({ title, items, onMovieClick }) => {
    const rowRef = useRef<HTMLDivElement>(null);
    const navigate = useNavigate();

    const scroll = (direction: 'left' | 'right') => {
        if (rowRef.current) {
            const { scrollLeft, clientWidth } = rowRef.current;
            const offset = direction === 'left' ? -clientWidth * 0.8 : clientWidth * 0.8;
            rowRef.current.scrollTo({ left: scrollLeft + offset, behavior: 'smooth' });
        }
    };

    // Strict Filter: Don't show empty boxes if URL is missing
    const visibleItems = items.filter(m => m.poster_path || m.poster || m.image);

    if (visibleItems.length === 0) return null;

    return (
        <div className="mb-10 group/row relative z-10">
            <div className="flex items-center justify-between px-[4%] mb-3">
                <h2 className="text-white font-bold text-lg md:text-xl cursor-pointer hover:text-[#5D5FFF] transition-colors">
                    {title}
                </h2>
                <button 
                    onClick={() => navigate(`/view-all/${title}`)}
                    className="text-xs font-bold text-[#5D5FFF] hover:underline opacity-80 hover:opacity-100"
                >
                    View All
                </button>
            </div>

            <div className="relative group">
                <button 
                    className="absolute left-0 top-0 bottom-8 z-20 bg-gradient-to-r from-black/80 to-transparent w-12 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-0"
                    onClick={() => scroll('left')}
                >
                    <ChevronLeft className="w-8 h-8 text-white drop-shadow-lg" />
                </button>

                <div 
                    ref={rowRef}
                    className="flex gap-4 overflow-x-auto no-scrollbar px-[4%] pb-4 scroll-smooth snap-x snap-mandatory"
                >
                    {visibleItems.map((item) => (
                        <div 
                            key={item.id} 
                            className="flex-none w-[140px] md:w-[180px] snap-start"
                        >
                            <Poster 
                                src={item.poster_path || item.poster || item.image}
                                title={item.title}
                                year={item.year}
                                rating={item.rating || item.vote_average}
                                onClick={() => onMovieClick(item)}
                            />
                        </div>
                    ))}
                </div>

                <button 
                    className="absolute right-0 top-0 bottom-8 z-20 bg-gradient-to-l from-black/80 to-transparent w-12 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => scroll('right')}
                >
                    <ChevronRight className="w-8 h-8 text-white drop-shadow-lg" />
                </button>
            </div>
        </div>
    );
};

export default Row;