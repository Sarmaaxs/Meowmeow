import React, { useState, useEffect } from 'react';

interface Props extends React.ImgHTMLAttributes<HTMLImageElement> {
    src: string;
    fallbackSrc?: string;
}

const SmartImage: React.FC<Props> = ({ src, alt, className, fallbackSrc, ...props }) => {
    const DEFAULT_FALLBACK = 'https://via.placeholder.com/300x450/1a1a1d/5d5fff?text=SARMAX';
    const [imgSrc, setImgSrc] = useState<string>(DEFAULT_FALLBACK);

    useEffect(() => {
        let fixed = src;

        if (!src) {
            fixed = fallbackSrc || DEFAULT_FALLBACK;
        } else if (src.startsWith('//')) {
            fixed = `https:${src}`;
        } else if (src.startsWith('/')) {
            // Automatically handle TMDB paths
            fixed = `https://image.tmdb.org/t/p/w500${src}`;
        } else if (src.startsWith('http')) {
            fixed = src;
        } else {
            // Assume it's a filename without path
            fixed = `https://image.tmdb.org/t/p/w500/${src}`;
        }

        setImgSrc(fixed);
    }, [src, fallbackSrc]);

    return (
        <div className={`relative overflow-hidden bg-[#1A1A1D] ${className}`} style={{ aspectRatio: '2/3', boxShadow: '0 10px 25px rgba(0,0,0,0.5)' }}>
            <img 
                src={imgSrc} 
                alt={alt || 'Poster'} 
                loading="lazy"
                className="w-full h-full object-cover transition-opacity duration-500"
                onError={(e) => {
                    e.currentTarget.onerror = null;
                    e.currentTarget.src = fallbackSrc || DEFAULT_FALLBACK;
                }}
                {...props}
            />
        </div>
    );
};

export default SmartImage;