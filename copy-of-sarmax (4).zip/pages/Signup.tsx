import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { AlertCircle, CheckCircle2, Eye, EyeOff, Mail, Lock, Sparkles, User } from 'lucide-react';
import Logo from '../components/Logo';

const Signup: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [step, setStep] = useState<'form' | 'success'>('form');
  const [loading, setLoading] = useState(false);
  
  const { signUp } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    // Simulate slight delay for premium feel
    setTimeout(async () => {
        try {
            if(password.length < 6) throw new Error("Password must be at least 6 characters");
            await signUp(email, password, name);
            setStep('success'); // Show success modal
        } catch (err: any) {
            setError(err.message);
            setLoading(false);
        }
    }, 1000);
  };

  const handleFinish = () => {
      navigate('/');
  };

  return (
    <div className="w-full min-h-screen flex items-center justify-center relative overflow-hidden bg-[#0D0D0F]">
       <div className="absolute inset-0 bg-black z-0">
        <img 
          src="https://assets.nflxext.com/ffe/siteui/vlv3/f841d4c7-10e1-40af-bcae-07a3f8dc141a/f6d7434e-d6de-4185-a6d4-c77a2d08737b/US-en-20220502-popsignuptwoweeks-perspective_alpha_website_large.jpg"
          onError={(e) => e.currentTarget.src = 'https://via.placeholder.com/1920x1080/0d0d0f/5d5fff?text=Sarmax+Cinema'}
          alt="Cinema Background"
          className="w-full h-full object-cover opacity-30 animate-fade-in scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0F] via-black/50 to-black/40"></div>
      </div>
      
      <div className="relative z-10 w-full max-w-[420px] mx-4">
        {step === 'form' ? (
            <div className="p-8 bg-[#151517]/90 border border-white/5 rounded-3xl shadow-2xl backdrop-blur-2xl animate-slide-up">
                <div className="flex justify-center mb-6">
                   <Logo className="h-10" />
                </div>
                <h2 className="text-2xl font-black mb-2 text-white text-center">Join Sarmax</h2>
                <p className="text-gray-400 text-center text-sm mb-8">Unlimited movies, TV shows, and more.</p>

                {error && (
                    <div className="bg-red-500/10 border border-red-500/20 text-red-200 p-3 rounded-xl mb-6 flex items-center gap-2 text-xs font-bold animate-pulse">
                        <AlertCircle className="w-4 h-4 flex-none" /> {error}
                    </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-1.5 group">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Full Name</label>
                        <div className="relative">
                            <input
                              onChange={(e) => setName(e.target.value)}
                              className="w-full p-4 pl-12 rounded-xl bg-[#0D0D0F] text-white border border-gray-800 focus:border-[#5D5FFF] focus:ring-1 focus:ring-[#5D5FFF] focus:outline-none transition-all placeholder-gray-600 text-sm font-medium"
                              type="text"
                              placeholder="John Doe"
                              required
                            />
                            <User className="absolute left-4 top-4 w-5 h-5 text-gray-500 group-focus-within:text-[#5D5FFF] transition-colors" />
                        </div>
                    </div>

                    <div className="space-y-1.5 group">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Email Address</label>
                        <div className="relative">
                            <input
                              onChange={(e) => setEmail(e.target.value)}
                              className="w-full p-4 pl-12 rounded-xl bg-[#0D0D0F] text-white border border-gray-800 focus:border-[#5D5FFF] focus:ring-1 focus:ring-[#5D5FFF] focus:outline-none transition-all placeholder-gray-600 text-sm font-medium"
                              type="email"
                              placeholder="name@example.com"
                              required
                            />
                            <Mail className="absolute left-4 top-4 w-5 h-5 text-gray-500 group-focus-within:text-[#5D5FFF] transition-colors" />
                        </div>
                    </div>

                    <div className="space-y-1.5 group">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1">Create Password</label>
                        <div className="relative">
                            <input
                              onChange={(e) => setPassword(e.target.value)}
                              className="w-full p-4 pl-12 pr-12 rounded-xl bg-[#0D0D0F] text-white border border-gray-800 focus:border-[#5D5FFF] focus:ring-1 focus:ring-[#5D5FFF] focus:outline-none transition-all placeholder-gray-600 text-sm font-medium"
                              type={showPassword ? "text" : "password"}
                              placeholder="Min 6 characters"
                              required
                            />
                            <Lock className="absolute left-4 top-4 w-5 h-5 text-gray-500 group-focus-within:text-[#5D5FFF] transition-colors" />
                            <button 
                                type="button"
                                onClick={() => setShowPassword(!showPassword)}
                                className="absolute right-4 top-4 text-gray-500 hover:text-white transition-colors"
                            >
                                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                            </button>
                        </div>
                    </div>

                    <button 
                        disabled={loading}
                        className="w-full bg-[#5D5FFF] hover:bg-[#4b4dcc] py-4 rounded-xl font-bold text-white text-sm tracking-wide transition-all shadow-[0_0_20px_rgba(93,95,255,0.3)] hover:shadow-[0_0_30px_rgba(93,95,255,0.5)] active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed mt-4 flex items-center justify-center gap-2"
                    >
                         {loading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : 'Create Account'}
                    </button>
                </form>

                 <div className="mt-6 text-center text-sm text-gray-400 border-t border-gray-800 pt-6">
                  Already have an account?&nbsp;
                  <Link to="/login" className="text-white font-bold hover:text-[#5D5FFF] transition-colors">
                    Log in
                  </Link>
                </div>
            </div>
        ) : (
            // Success State - Confirms Email Sent
            <div className="p-10 bg-[#151517]/95 border border-[#5D5FFF]/20 rounded-3xl shadow-[0_0_50px_rgba(93,95,255,0.2)] backdrop-blur-2xl text-center animate-fade-in flex flex-col items-center">
                 <div className="w-20 h-20 rounded-full bg-[#5D5FFF]/10 flex items-center justify-center mb-6 animate-pulse">
                    <CheckCircle2 className="w-10 h-10 text-[#5D5FFF]" />
                 </div>
                 <h2 className="text-3xl font-black text-white mb-2">Thank You!</h2>
                 <p className="text-gray-300 mb-6 max-w-[280px]">We've sent a welcome email to <span className="text-white font-bold">{email}</span>.</p>
                 
                 <button 
                    onClick={handleFinish}
                    className="w-full bg-white text-black hover:bg-gray-200 py-4 rounded-xl font-bold text-sm tracking-wide transition-all shadow-lg flex items-center justify-center gap-2"
                >
                    <Sparkles className="w-4 h-4 text-[#5D5FFF]" /> Start Streaming
                 </button>
            </div>
        )}
      </div>
    </div>
  );
};

export default Signup;