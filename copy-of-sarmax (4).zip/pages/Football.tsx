
import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import { Play, Calendar, Trophy, Tv, X, BarChart2, Activity } from 'lucide-react';
import { sportsService } from '../services/sports';
import { Match } from '../types';

const Football: React.FC = () => {
  const [matches, setMatches] = useState<Match[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [activeTab, setActiveTab] = useState<'stream' | 'stats'>('stream');

  useEffect(() => {
    const unsubscribe = sportsService.subscribe((updatedMatches) => {
        setMatches(updatedMatches);
        if (selectedMatch) {
            const current = updatedMatches.find(m => m.id === selectedMatch.id);
            if (current) setSelectedMatch(current);
        }
    });
    return () => unsubscribe();
  }, [selectedMatch]);

  return (
    <div className="min-h-screen bg-[#0D0D0F] pb-24">
      <Navbar isScrolled={true} />
      
      <div className="pt-24 px-4 md:px-12 max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-8 animate-fade-in">
            <div className="p-3 bg-[#5D5FFF] rounded-xl shadow-[0_0_30px_rgba(93,95,255,0.3)]">
                <Trophy className="w-8 h-8 text-white" />
            </div>
            <div>
                <h1 className="text-3xl font-black text-white">Football Hub</h1>
                <p className="text-gray-400">Real-Time Scores & Streaming</p>
            </div>
        </div>

        {/* Live Section */}
        <section className="mb-12">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse shadow-[0_0_10px_red]"></span> Live Now
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {matches.filter(m => m.status === 'LIVE').map(match => (
                    <div key={match.id} className="bg-[#1A1A1D] border border-[#5D5FFF]/20 rounded-2xl p-6 relative overflow-hidden group hover:border-[#5D5FFF]/50 transition-all shadow-lg">
                        <div className="flex justify-between items-center mb-6">
                            <span className="text-xs text-gray-500 font-bold uppercase tracking-widest">{match.league}</span>
                            <span className="text-xs text-[#5D5FFF] font-bold animate-pulse flex items-center gap-1">● {match.minute}'</span>
                        </div>
                        
                        <div className="flex justify-between items-center relative z-10">
                             <div className="text-center w-1/3">
                                <div className="w-12 h-12 bg-gray-800 rounded-full mx-auto mb-2 flex items-center justify-center font-bold text-white text-xl border border-white/10 shadow-inner">{match.home[0]}</div>
                                <span className="font-bold text-white block">{match.home}</span>
                             </div>
                             <div className="text-center w-1/3">
                                 <div className="text-3xl font-black text-white tracking-widest bg-[#0D0D0F] px-4 py-2 rounded-xl border border-[#5D5FFF]/30 shadow-[0_0_15px_rgba(93,95,255,0.15)]">{match.score}</div>
                             </div>
                             <div className="text-center w-1/3">
                                <div className="w-12 h-12 bg-gray-800 rounded-full mx-auto mb-2 flex items-center justify-center font-bold text-white text-xl border border-white/10 shadow-inner">{match.away[0]}</div>
                                <span className="font-bold text-white block">{match.away}</span>
                             </div>
                        </div>

                        <div className="mt-6 flex gap-2">
                             <button onClick={() => {setSelectedMatch(match); setActiveTab('stream');}} className="flex-1 bg-[#5D5FFF] hover:bg-[#4b4dcc] py-2.5 rounded-xl text-white font-bold text-sm transition-all shadow-[0_0_15px_rgba(93,95,255,0.2)] flex items-center justify-center gap-2">
                                <Play className="w-4 h-4 fill-white" /> Watch Stream
                             </button>
                             <button onClick={() => {setSelectedMatch(match); setActiveTab('stats');}} className="flex-1 bg-gray-800 hover:bg-gray-700 py-2.5 rounded-xl text-white font-bold text-sm transition-colors flex items-center justify-center gap-2">
                                <Activity className="w-4 h-4" /> Stats
                             </button>
                        </div>
                    </div>
                ))}
            </div>
        </section>
      </div>

      {/* Detail Modal */}
      {selectedMatch && (
        <div className="fixed inset-0 z-[60] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 animate-fade-in" onClick={(e) => e.target === e.currentTarget && setSelectedMatch(null)}>
             <div className="w-full max-w-4xl bg-[#151517] rounded-2xl overflow-hidden shadow-2xl border border-[#5D5FFF]/20 flex flex-col max-h-[90vh] animate-slide-up">
                 <div className="flex justify-between items-center p-4 border-b border-white/5 bg-[#1A1A1D]">
                    <div className="flex gap-4">
                        <button onClick={() => setActiveTab('stream')} className={`text-sm font-bold uppercase transition-colors ${activeTab === 'stream' ? 'text-[#5D5FFF] drop-shadow-[0_0_5px_rgba(93,95,255,0.5)]' : 'text-gray-500'}`}>Stream</button>
                        <button onClick={() => setActiveTab('stats')} className={`text-sm font-bold uppercase transition-colors ${activeTab === 'stats' ? 'text-[#5D5FFF] drop-shadow-[0_0_5px_rgba(93,95,255,0.5)]' : 'text-gray-500'}`}>Live Stats</button>
                    </div>
                    <button onClick={() => setSelectedMatch(null)}><X className="w-6 h-6 text-gray-400 hover:text-white hover:rotate-90 transition-all" /></button>
                 </div>
                 
                 <div className="flex-1 overflow-y-auto bg-black">
                     {activeTab === 'stream' ? (
                        <div className="aspect-video relative">
                            {/* Fallback Search Stream */}
                            <iframe 
                                width="100%" height="100%" 
                                src={`https://www.youtube.com/embed?listType=search&list=${encodeURIComponent(`football live ${selectedMatch.home} vs ${selectedMatch.away}`)}`} 
                                title="Stream" frameBorder="0" allowFullScreen
                            ></iframe>
                        </div>
                     ) : (
                        <div className="p-8 bg-[#0D0D0F]">
                            {/* Possession Bar */}
                            <div className="mb-8">
                                <div className="flex justify-between text-xs font-bold text-gray-400 mb-2">
                                    <span>{selectedMatch.home}</span>
                                    <span>Possession</span>
                                    <span>{selectedMatch.away}</span>
                                </div>
                                <div className="h-4 bg-gray-800 rounded-full overflow-hidden flex">
                                    <div className="h-full bg-[#5D5FFF] shadow-[0_0_10px_#5D5FFF]" style={{width: `${selectedMatch.possession?.[0] || 50}%`}}></div>
                                    <div className="h-full bg-red-500 shadow-[0_0_10px_red]" style={{width: `${selectedMatch.possession?.[1] || 50}%`}}></div>
                                </div>
                            </div>
                            
                            {/* Events */}
                            <div className="space-y-4">
                                <h3 className="text-white font-bold mb-2">Match Events</h3>
                                {selectedMatch.events?.map((ev, i) => (
                                    <div key={i} className={`flex items-center gap-4 ${ev.team === 'away' ? 'flex-row-reverse text-right' : ''} animate-slide-up`} style={{animationDelay: `${i*0.1}s`}}>
                                        <div className="text-xs font-mono text-gray-500">{ev.time}</div>
                                        <div className={`px-4 py-2 rounded-lg border text-sm text-white shadow-lg ${ev.type === 'goal' ? 'bg-[#5D5FFF]/20 border-[#5D5FFF]/50 shadow-[0_0_10px_rgba(93,95,255,0.2)]' : 'bg-[#1A1A1D] border-white/5'}`}>
                                            {ev.type === 'goal' && '⚽ '}
                                            {ev.text}
                                        </div>
                                    </div>
                                ))}
                                {(!selectedMatch.events || selectedMatch.events.length === 0) && <p className="text-center text-gray-500">No events yet.</p>}
                            </div>
                        </div>
                     )}
                 </div>
             </div>
        </div>
      )}
    </div>
  );
};

export default Football;
