
import React, { useState } from 'react';
import { CreditCard, Lock, ShieldCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { authService } from '../services/firebase';

const Payment: React.FC = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [cardNum, setCardNum] = useState('');
    
    const handlePayment = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        
        setTimeout(async () => {
            await authService.processPayment(); 
            setLoading(false);
            alert("Payment Successful! Welcome to Premium.");
            navigate('/');
        }, 2000);
    };

    return (
        <div className="min-h-screen bg-[#0D0D0F] text-white pt-20 pb-24">
            <Navbar isScrolled={true} />
            <div className="max-w-md mx-auto px-4 animate-slide-up">
                <div className="text-center mb-8">
                    <p className="text-[#5D5FFF] font-bold text-xs uppercase tracking-widest mb-2">Step 3 of 3</p>
                    <h1 className="text-2xl font-black">Set up your payment</h1>
                    <p className="text-gray-400 text-sm mt-2">Your membership starts as soon as you set up payment.</p>
                    <div className="flex justify-center items-center gap-1 text-xs font-bold text-gray-500 mt-2">
                        <Lock className="w-3 h-3" /> Encrypted & Secure
                    </div>
                </div>

                <div className="bg-[#1A1A1D] border border-[#5D5FFF]/20 text-white rounded-2xl overflow-hidden shadow-[0_0_30px_rgba(0,0,0,0.5)]">
                    <div className="bg-[#222] p-4 border-b border-white/5 flex justify-between items-center">
                        <span className="font-bold text-sm text-gray-300">Credit or Debit Card</span>
                        <div className="flex gap-1">
                            <div className="w-8 h-5 bg-blue-600 rounded"></div>
                            <div className="w-8 h-5 bg-orange-500 rounded"></div>
                            <div className="w-8 h-5 bg-red-500 rounded"></div>
                        </div>
                    </div>
                    
                    <form onSubmit={handlePayment} className="p-6 space-y-4">
                        <div className="space-y-1">
                            <input 
                                type="text" 
                                placeholder="Card Number" 
                                className="w-full p-3 bg-[#0D0D0F] border border-gray-700 rounded-xl text-sm font-medium focus:border-[#5D5FFF] focus:ring-1 focus:ring-[#5D5FFF] outline-none transition-all"
                                maxLength={19}
                                value={cardNum}
                                onChange={e => setCardNum(e.target.value.replace(/\D/g,'').replace(/(.{4})/g,'$1 ').trim())}
                                required 
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <input type="text" placeholder="Expiration (MM/YY)" className="w-full p-3 bg-[#0D0D0F] border border-gray-700 rounded-xl text-sm font-medium focus:border-[#5D5FFF] focus:ring-1 focus:ring-[#5D5FFF] outline-none transition-all" required />
                            <input type="text" placeholder="CVV" maxLength={3} className="w-full p-3 bg-[#0D0D0F] border border-gray-700 rounded-xl text-sm font-medium focus:border-[#5D5FFF] focus:ring-1 focus:ring-[#5D5FFF] outline-none transition-all" required />
                        </div>
                        <input type="text" placeholder="Name on Card" className="w-full p-3 bg-[#0D0D0F] border border-gray-700 rounded-xl text-sm font-medium focus:border-[#5D5FFF] focus:ring-1 focus:ring-[#5D5FFF] outline-none transition-all" required />
                        
                        <div className="bg-[#5D5FFF]/10 p-3 rounded-xl border border-[#5D5FFF]/20 text-xs text-gray-400 flex justify-between items-center">
                            <span>$19.99/month</span>
                            <span className="font-bold text-[#5D5FFF]">Premium</span>
                        </div>

                        <button 
                            disabled={loading}
                            className="w-full bg-[#5D5FFF] hover:bg-[#4b4dcc] text-white py-4 rounded-xl font-bold text-lg transition-all shadow-[0_0_20px_rgba(93,95,255,0.3)] hover:shadow-[0_0_30px_rgba(93,95,255,0.5)] disabled:opacity-70 flex items-center justify-center gap-2"
                        >
                            {loading ? "Processing..." : "Start Membership"}
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Payment;
