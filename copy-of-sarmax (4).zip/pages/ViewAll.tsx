import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { ArrowLeft, Play } from 'lucide-react';
import { MOCK_DATA, getPosterUrl } from '../constants';
import { Movie } from '../types';
import SmartImage from '../components/SmartImage';
import Modal from '../components/Modal';

const ViewAll: React.FC = () => {
  const { category } = useParams<{ category: string }>();
  const navigate = useNavigate();
  const [items, setItems] = useState<Movie[]>([]);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);

  useEffect(() => {
    if (category) {
      // Find the category in MOCK_DATA or flatten all items if generic
      const foundCat = MOCK_DATA.categories.find(c => c.title === category);
      if (foundCat) {
        setItems(foundCat.items);
      } else {
        // Fallback: show all movies if category not found specifically
        const all = MOCK_DATA.categories.flatMap(c => c.items);
        setItems(all);
      }
    }
  }, [category]);

  return (
    <div className="min-h-screen bg-[#0D0D0F] text-white pb-24">
      <Navbar isScrolled={true} />
      
      <div className="pt-24 px-4 md:px-12 max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 rounded-full bg-[#1A1A1D] hover:bg-[#5D5FFF] transition-colors group"
          >
            <ArrowLeft className="w-6 h-6 text-gray-400 group-hover:text-white" />
          </button>
          <h1 className="text-3xl font-black text-white">{category || 'All Movies'}</h1>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {items.map((movie) => (
            <div 
              key={movie.id} 
              className="group relative bg-[#1A1A1D] rounded-xl overflow-hidden cursor-pointer hover:scale-[1.02] transition-all duration-200 shadow-md hover:shadow-[0_0_20px_rgba(93,95,255,0.2)] gpu-accelerated"
              onClick={() => setSelectedMovie(movie)}
            >
                <div className="aspect-[2/3] w-full relative bg-[#222]">
                    <SmartImage 
                        src={getPosterUrl(movie)}
                        alt={movie.title}
                        className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity"
                        referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/50">
                        <Play className="fill-white w-8 h-8 text-white drop-shadow-lg" />
                    </div>
                    <div className="absolute top-2 right-2 bg-[#5D5FFF] text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-md">
                        HD
                    </div>
                </div>
                <div className="p-3">
                    <h3 className="font-bold text-white text-sm truncate">{movie.title}</h3>
                    <div className="flex items-center justify-between mt-1 text-xs text-gray-400">
                        <span>{movie.year}</span>
                        <span className="text-[#5D5FFF] font-bold">{movie.rating}</span>
                    </div>
                </div>
            </div>
          ))}
        </div>
      </div>

      {selectedMovie && (
        <Modal movie={selectedMovie} onClose={() => setSelectedMovie(null)} />
      )}
    </div>
  );
};

export default ViewAll;
