
import React, { useState } from 'react';
import { Check, X, Smartphone, Monitor, Tablet, Tv } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { useAuth } from '../context/AuthContext';

const Plans: React.FC = () => {
  const [selectedPlan, setSelectedPlan] = useState<string>('Basic');
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleSubscribe = () => {
      if (!user) {
          navigate('/signup');
      } else {
          localStorage.setItem('sarmax_plan', selectedPlan);
          navigate('/payment');
      }
  }

  return (
    <div className="min-h-screen bg-[#0D0D0F] text-white pt-20 pb-24 font-sans">
      <Navbar isScrolled={true} />
      
      <div className="max-w-5xl mx-auto px-4 py-8 animate-slide-up">
        <div className="text-center mb-10">
            <p className="text-[#5D5FFF] font-bold uppercase tracking-widest text-xs mb-2">Step 2 of 3</p>
            <h1 className="text-3xl md:text-4xl font-black mb-4">Choose your plan</h1>
            <div className="flex flex-col items-center gap-2 text-gray-400 text-sm">
                <div className="flex items-center gap-2"><Check className="w-4 h-4 text-[#5D5FFF]"/> Watch all you want. Ad-free.</div>
                <div className="flex items-center gap-2"><Check className="w-4 h-4 text-[#5D5FFF]"/> Recommendations just for you.</div>
                <div className="flex items-center gap-2"><Check className="w-4 h-4 text-[#5D5FFF]"/> Change or cancel anytime.</div>
            </div>
        </div>

        {/* Desktop Table View */}
        <div className="hidden md:block bg-[#1A1A1D] rounded-2xl overflow-hidden border border-white/5 shadow-2xl">
            <div className="grid grid-cols-4 border-b border-white/5">
                <div className="p-6 flex items-end"></div>
                {['Basic', 'Standard', 'Premium'].map(plan => (
                    <div key={plan} className="p-6 text-center relative">
                        <div className={`w-24 h-24 mx-auto rounded-2xl flex items-center justify-center font-bold text-lg mb-4 cursor-pointer transition-all ${selectedPlan === plan ? 'bg-[#5D5FFF] text-white scale-110 shadow-[0_0_20px_rgba(93,95,255,0.4)]' : 'bg-gray-800 text-gray-400 opacity-60 hover:opacity-100'}`}
                             onClick={() => setSelectedPlan(plan)}
                        >
                            {plan}
                        </div>
                        {selectedPlan === plan && <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-[#1A1A1D] rotate-45 translate-y-2 border-t border-l border-white/5"></div>}
                    </div>
                ))}
            </div>

            <Row label="Monthly price" basic="$9.99" standard="$15.49" premium="$19.99" selected={selectedPlan} />
            <Row label="Video quality" basic="Good" standard="Better" premium="Best" selected={selectedPlan} />
            <Row label="Resolution" basic="720p (HD)" standard="1080p (Full HD)" premium="4K (Ultra HD) + HDR" selected={selectedPlan} />
            <Row label="Downloads" basic={<Check className="mx-auto w-5 h-5"/>} standard={<Check className="mx-auto w-5 h-5"/>} premium={<Check className="mx-auto w-5 h-5"/>} selected={selectedPlan} />
            
            <div className="grid grid-cols-4 p-6 bg-[#0D0D0F]/50">
                <div></div>
                <div className="col-span-3 text-center">
                    <button onClick={handleSubscribe} className="w-full max-w-md bg-[#5D5FFF] hover:bg-[#4b4dcc] py-4 rounded-xl text-white font-bold text-xl transition-all shadow-[0_0_20px_rgba(93,95,255,0.3)]">
                        Subscribe to {selectedPlan}
                    </button>
                </div>
            </div>
        </div>

        {/* Mobile Card View */}
        <div className="md:hidden space-y-6">
            {[
                { name: 'Basic', price: '$9.99', quality: 'Good', res: '720p' },
                { name: 'Standard', price: '$15.49', quality: 'Better', res: '1080p' },
                { name: 'Premium', price: '$19.99', quality: 'Best', res: '4K+HDR' }
            ].map(plan => (
                <div 
                    key={plan.name}
                    onClick={() => setSelectedPlan(plan.name)}
                    className={`bg-[#1A1A1D] rounded-2xl p-6 border transition-all relative overflow-hidden ${selectedPlan === plan.name ? 'border-[#5D5FFF] shadow-[0_0_20px_rgba(93,95,255,0.2)]' : 'border-white/5'}`}
                >
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-bold text-white">{plan.name}</h3>
                        {selectedPlan === plan.name && <div className="w-6 h-6 bg-[#5D5FFF] rounded-full flex items-center justify-center"><Check className="w-4 h-4 text-white" /></div>}
                    </div>
                    <div className="text-2xl font-bold mb-4 text-white">{plan.price}<span className="text-sm text-gray-500 font-normal">/mo</span></div>
                    <div className="space-y-2 text-sm text-gray-400">
                        <div className="flex justify-between border-b border-white/5 pb-2"><span>Quality</span> <span className="text-white">{plan.quality}</span></div>
                        <div className="flex justify-between border-b border-white/5 pb-2"><span>Resolution</span> <span className="text-white">{plan.res}</span></div>
                    </div>
                </div>
            ))}
             <button onClick={handleSubscribe} className="w-full bg-[#5D5FFF] py-4 rounded-xl text-white font-bold text-lg fixed bottom-4 left-4 right-4 shadow-xl z-50 w-[calc(100%-32px)] hover:bg-[#4b4dcc] transition-colors">
                Subscribe
            </button>
        </div>
      </div>
    </div>
  );
};

const Row: React.FC<{label: string, basic: any, standard: any, premium: any, selected: string}> = ({label, basic, standard, premium, selected}) => {
    const getStyle = (plan: string) => selected === plan ? 'text-[#5D5FFF] font-bold' : 'text-gray-400';
    return (
        <div className="grid grid-cols-4 border-b border-white/5 py-4 px-6 hover:bg-white/5 transition-colors">
            <div className="text-sm font-medium text-gray-300 flex items-center">{label}</div>
            <div className={`text-center ${getStyle('Basic')}`}>{basic}</div>
            <div className={`text-center ${getStyle('Standard')}`}>{standard}</div>
            <div className={`text-center ${getStyle('Premium')}`}>{premium}</div>
        </div>
    )
}

export default Plans;
