import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { AlertCircle, Eye, EyeOff, Facebook, Mail, Chrome, Lock } from 'lucide-react';
import Logo from '../components/Logo';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { logIn } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    // Simulate verification delay for premium feel
    setTimeout(async () => {
        try {
            await logIn(email, password);
            navigate('/');
        } catch (err: any) {
            setError('Invalid credentials. Please try again.');
            setLoading(false);
        }
    }, 800);
  };

  return (
    <div className="w-full min-h-screen flex items-center justify-center relative overflow-hidden bg-[#0D0D0F]">
      {/* Cinematic Background with Robust Fallback */}
      <div className="absolute inset-0 bg-black z-0">
        <img 
          src="https://assets.nflxext.com/ffe/siteui/vlv3/f841d4c7-10e1-40af-bcae-07a3f8dc141a/f6d7434e-d6de-4185-a6d4-c77a2d08737b/US-en-20220502-popsignuptwoweeks-perspective_alpha_website_large.jpg"
          onError={(e) => e.currentTarget.src = 'https://example.com/default_login.jpg'}
          alt="Cinema Background"
          className="w-full h-full object-cover opacity-40 animate-fade-in scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0F] via-black/50 to-black/40"></div>
      </div>
      
      {/* Glassmorphism Card */}
      <div className="relative z-10 w-full max-w-[420px] mx-4 p-8 bg-[#151517]/90 border border-white/5 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] backdrop-blur-2xl animate-slide-up">
        <div className="flex justify-center mb-8 scale-110">
           <Logo className="h-10" />
        </div>

        <h2 className="text-2xl md:text-3xl font-black mb-2 text-white text-center tracking-tight">Welcome Back</h2>
        <p className="text-gray-400 text-center text-sm mb-8">Enter your details to continue streaming.</p>
        
        {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-200 p-3 rounded-xl mb-6 flex items-center gap-2 text-xs font-bold animate-pulse">
                <AlertCircle className="w-4 h-4 flex-none" /> {error}
            </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-1.5 group">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1 group-focus-within:text-[#5D5FFF] transition-colors">Email</label>
                <div className="relative">
                    <input
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full p-4 pl-12 rounded-xl bg-[#0D0D0F] text-white border border-gray-800 focus:border-[#5D5FFF] focus:ring-1 focus:ring-[#5D5FFF] focus:outline-none transition-all placeholder-gray-600 text-sm font-medium shadow-inner"
                      type="email"
                      placeholder="name@example.com"
                      required
                    />
                    <Mail className="absolute left-4 top-4 w-5 h-5 text-gray-500 group-focus-within:text-[#5D5FFF] transition-colors" />
                </div>
            </div>

            <div className="space-y-1.5 group">
                 <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-1 group-focus-within:text-[#5D5FFF] transition-colors">Password</label>
                 <div className="relative">
                    <input
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full p-4 pl-12 pr-12 rounded-xl bg-[#0D0D0F] text-white border border-gray-800 focus:border-[#5D5FFF] focus:ring-1 focus:ring-[#5D5FFF] focus:outline-none transition-all placeholder-gray-600 text-sm font-medium shadow-inner"
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      required
                    />
                    <Lock className="absolute left-4 top-4 w-5 h-5 text-gray-500 group-focus-within:text-[#5D5FFF] transition-colors" />
                    <button 
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-4 text-gray-500 hover:text-white transition-colors"
                    >
                        {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                 </div>
            </div>

            <div className="flex justify-between items-center text-xs font-medium text-gray-400 pt-2">
                <label className="flex items-center gap-2 cursor-pointer hover:text-white transition-colors select-none">
                  <div className="relative">
                      <input type="checkbox" className="peer sr-only" />
                      <div className="w-4 h-4 rounded bg-[#2A2A2D] border border-gray-700 peer-checked:bg-[#5D5FFF] peer-checked:border-[#5D5FFF] transition-colors"></div>
                  </div>
                  Remember me
                </label>
                <Link to="/" className="hover:text-[#5D5FFF] transition-colors">Forgot Password?</Link>
            </div>

            <button 
                disabled={loading}
                className="w-full bg-[#5D5FFF] hover:bg-[#4b4dcc] py-4 rounded-xl font-bold text-white text-sm tracking-wide transition-all shadow-[0_0_20px_rgba(93,95,255,0.3)] hover:shadow-[0_0_30px_rgba(93,95,255,0.5)] active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2 mt-4"
            >
                 {loading ? (
                     <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Verifying...</>
                 ) : 'Sign In'}
            </button>
        </form>
        
        <div className="my-8 flex items-center gap-4">
            <div className="h-[1px] bg-gradient-to-r from-transparent via-gray-700 to-transparent flex-1"></div>
            <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">Or continue with</span>
            <div className="h-[1px] bg-gradient-to-r from-transparent via-gray-700 to-transparent flex-1"></div>
        </div>

        <div className="grid grid-cols-2 gap-4">
            <button className="flex items-center justify-center gap-2 p-3 rounded-xl bg-[#0D0D0F] hover:bg-[#202022] border border-gray-800 hover:border-gray-600 transition-all text-sm font-bold text-gray-300 hover:text-white group">
                <Chrome className="w-4 h-4 text-white group-hover:scale-110 transition-transform" /> Google
            </button>
            <button className="flex items-center justify-center gap-2 p-3 rounded-xl bg-[#0D0D0F] hover:bg-[#202022] border border-gray-800 hover:border-gray-600 transition-all text-sm font-bold text-gray-300 hover:text-white group">
                <Facebook className="w-4 h-4 text-[#1877F2] group-hover:scale-110 transition-transform" /> Facebook
            </button>
        </div>

        <div className="mt-8 text-center text-sm text-gray-400">
          New to Sarmax?&nbsp;
          <Link to="/signup" className="text-white font-bold hover:text-[#5D5FFF] transition-colors">
            Create account
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;